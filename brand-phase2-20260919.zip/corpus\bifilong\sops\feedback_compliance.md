---
name: bifilong-compliance-is-hard
description: 必慧龙违禁词 v2.0 是硬约束，所有营销产出前必跑词库自检
metadata:
  type: feedback
---

**规则**：所有营销内容（小红书/公众号/视频号/海报/详情页/直播话术/客服话术）生成前必须 100% 调用 [[wiki/活动海报提示词及文案/必慧龙违禁词与替代用语库 v2.0]]（594 + 126 条）。

**Why:** 用户多次明确这是硬约束，宁愿改稿也不踩 A 级红线；2024 SAMR 远鉴恒辉案等处罚案例已证明雷区真实存在。

**How to apply:**
- 任何对外发布物料 → 第一步先 Read 该词库
- A 级（治疗/预防/抗病毒/增强免疫力等）零容忍
- B 级（最/第一/唯一）需审核替换
- C 级（神器/必备/智商税）立即替换
- D 级暗示词（自护力/屏障/排毒）直接删除
- 详见 [[reference_compliance_lib]]

相关：[[feedback_long_height_redline]]（钙片特殊红线）
相关：[[reference_compliance_lib]]（词库物理位置）