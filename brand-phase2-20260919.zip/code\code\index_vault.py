"""
index_vault.py — 3 品牌独立 RAG 索引器(方案 α:1 个通用 + --brand)

主导方:本机 Claude(Phase 1)
不动方:Hermes
拍板:D6(α 方案)+ D13(3 品牌人格名 慧慧/诺诺/鑫鑫)

用法:
    # 索引必慧龙
    python -m rag.index_vault --brand=bifilong

    # 索引圣诺熊
    python -m rag.index_vault --brand=shengnuoxiong

    # 索引鑫耀
    python -m rag.index_vault --brand=xinyao

    # 重建索引(可选,默认 skip if exists)
    python -m rag.index_vault --brand=bifilong --rebuild

    # 自定义 corpus 路径(可选,默认按 BRAND 自动推断)
    python -m rag.index_vault --brand=bifilong --corpus=/custom/path

产出:
    /home/ubuntu/work/<brand>-bot/rag/index_<brand>.pkl
"""

import argparse
import hashlib
import json
import logging
import pickle
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional

# ============== 配置(待 P1-D1 ~ P1-D4 拍板) ==============

# 拍板后填入:embedding 模型路径
EMBEDDING_MODEL = "BAAI/bge-small-zh-v1.5"  # P1-D1 候选 a
EMBEDDING_DIM = 512  # bge-small-zh-v1.5 默认维度

# 拍板后填入:chunk 参数
CHUNK_SIZE = 400  # P1-D3 候选 中
CHUNK_OVERLAP = 80

# 拍板后填入:路径模板
CORPUS_ROOT = Path("/home/ubuntu/work")
INDEX_ROOT = CORPUS_ROOT  # 索引产物与 brand-bot 同目录

BRAND_TO_BOT_DIR = {
    "bifilong": "bifilong-bot",
    "shengnuoxiong": "shengnuox-bot",
    "xinyao": "xinyao-bot",
}

BRAND_TO_PERSONA = {
    "bifilong": "慧慧",
    "shengnuoxiong": "诺诺",
    "xinyao": "鑫鑫",
}

# ============== 数据结构 ==============

@dataclass
class Chunk:
    """索引中的一个 chunk(一段文本 + 元数据)"""
    chunk_id: str          # 唯一 ID:brand:source_path:chunk_index
    brand: str             # bifilong / shengnuoxiong / xinyao
    source_path: str       # 原文绝对路径
    source_filename: str   # 原文文件名(便于溯源)
    chunk_index: int       # 在原文中的块序号(从 0 开始)
    text: str              # chunk 文本内容
    embedding: List[float] # 512 维向量(bge-small-zh-v1.5)
    metadata: dict         # 扩展元数据(产品名 / 类别 / 月龄段等)


# ============== 工具函数 ==============

def setup_logger(brand: str) -> logging.Logger:
    """统一 logger"""
    logger = logging.getLogger(f"index_vault.{brand}")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            f"[%(asctime)s] [index_vault.{brand}] %(levelname)s: %(message)s"
        ))
        logger.addHandler(handler)
    return logger


def get_corpus_dir(brand: str, custom_corpus: Optional[str] = None) -> Path:
    """根据 brand 获取 corpus 目录"""
    if custom_corpus:
        return Path(custom_corpus)

    bot_dir = BRAND_TO_BOT_DIR[brand]
    return CORPUS_ROOT / bot_dir / "rag" / "corpus"


def get_index_path(brand: str) -> Path:
    """根据 brand 获取索引产物路径"""
    bot_dir = BRAND_TO_BOT_DIR[brand]
    return INDEX_ROOT / bot_dir / "rag" / f"index_{brand}.pkl"


def iter_markdown_files(corpus_dir: Path):
    """递归遍历 corpus 目录下所有 .md 文件"""
    if not corpus_dir.exists():
        raise FileNotFoundError(f"corpus 目录不存在:{corpus_dir}")
    yield from sorted(corpus_dir.rglob("*.md"))


def split_into_chunks(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[str]:
    """简单的固定长度 chunk 切分(按字符数)

    优化方向(Phase 1 v0.1 → v0.2):
    - 按段落切分(保留语义边界)
    - 按句号切分(避免句子被截断)
    - 按 Markdown 标题切分(保留文档结构)
    """
    if not text:
        return []

    chunks = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = min(start + chunk_size, text_len)
        chunk_text = text[start:end].strip()
        if chunk_text:
            chunks.append(chunk_text)
        if end == text_len:
            break
        start = end - overlap

    return chunks


def compute_file_hash(file_path: Path) -> str:
    """计算文件 sha256(用于幂等检查)"""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for block in iter(lambda: f.read(4096), b""):
            h.update(block)
    return h.hexdigest()


# ============== Embedding(待 P1-D1 拍板后实装) ==============

class Embedder:
    """Embedding 模型封装(支持懒加载)"""

    def __init__(self, model_name: str = EMBEDDING_MODEL):
        self.model_name = model_name
        self._model = None

    def _lazy_load(self):
        if self._model is None:
            try:
                from FlagEmbedding import FlagModel
                self._model = FlagModel(self.model_name, query_instruction_for_retrieval="为这个句子生成表示以用于检索相关文章:")
            except ImportError:
                # fallback:sentence-transformers
                from sentence_transformers import SentenceTransformer
                self._model = SentenceTransformer(self.model_name)
        return self._model

    def embed(self, texts: List[str]) -> List[List[float]]:
        """批量 embedding"""
        if not texts:
            return []
        model = self._lazy_load()
        if hasattr(model, "encode"):  # sentence-transformers / FlagModel
            vecs = model.encode(texts, normalize_embeddings=True)
            return vecs.tolist()
        raise RuntimeError(f"未知 embedding 模型接口:{type(model)}")


# ============== 主流程 ==============

def build_index(brand: str, corpus_dir: Path, logger: logging.Logger, embedder: Embedder) -> List[Chunk]:
    """构建 brand 的索引"""
    chunks: List[Chunk] = []

    md_files = list(iter_markdown_files(corpus_dir))
    logger.info(f"发现 {len(md_files)} 个 .md 文件,开始构建索引...")

    for i, md_file in enumerate(md_files, 1):
        text = md_file.read_text(encoding="utf-8")
        # 去掉 frontmatter(开头 --- 到 --- 之间)
        if text.startswith("---"):
            end = text.find("\n---", 3)
            if end != -1:
                text = text[end + 4:].strip()

        text_chunks = split_into_chunks(text)
        if not text_chunks:
            continue

        # batch embedding
        embeddings = embedder.embed(text_chunks)

        for chunk_idx, (chunk_text, embedding) in enumerate(zip(text_chunks, embeddings)):
            chunk = Chunk(
                chunk_id=f"{brand}:{md_file.absolute()}:{chunk_idx}",
                brand=brand,
                source_path=str(md_file.absolute()),
                source_filename=md_file.name,
                chunk_index=chunk_idx,
                text=chunk_text,
                embedding=embedding,
                metadata={
                    "persona": BRAND_TO_PERSONA[brand],
                    "file_sha256": compute_file_hash(md_file),
                    "char_count": len(chunk_text),
                },
            )
            chunks.append(chunk)

        if i % 10 == 0:
            logger.info(f"  已处理 {i}/{len(md_files)} 个文件,当前 {len(chunks)} 个 chunks")

    logger.info(f"索引构建完成:共 {len(chunks)} 个 chunks")
    return chunks


def save_index(index_path: Path, chunks: List[Chunk], logger: logging.Logger):
    """保存索引到 pickle"""
    index_path.parent.mkdir(parents=True, exist_ok=True)
    with open(index_path, "wb") as f:
        pickle.dump(chunks, f, protocol=pickle.HIGHEST_PROTOCOL)
    size_mb = index_path.stat().st_size / (1024 * 1024)
    logger.info(f"索引已保存:{index_path}({size_mb:.2f} MB,{len(chunks)} chunks)")


def main():
    parser = argparse.ArgumentParser(
        description="3 品牌独立 RAG 索引器(方案 α:1 个通用 + --brand)",
    )
    parser.add_argument(
        "--brand",
        type=str,
        required=True,
        choices=["bifilong", "shengnuoxiong", "xinyao"],
        help="品牌名:bifilong(必慧龙)/ shengnuoxiong(圣诺熊)/ xinyao(鑫耀)",
    )
    parser.add_argument(
        "--rebuild",
        action="store_true",
        help="强制重建索引(默认:如果索引存在则跳过)",
    )
    parser.add_argument(
        "--corpus",
        type=str,
        default=None,
        help="自定义 corpus 路径(默认按 BRAND 自动推断)",
    )

    args = parser.parse_args()
    brand = args.brand

    logger = setup_logger(brand)
    logger.info(f"=== 开始为 [{BRAND_TO_PERSONA[brand]}({brand})] 构建索引 ===")

    # 0. 幂等检查
    index_path = get_index_path(brand)
    if index_path.exists() and not args.rebuild:
        logger.info(f"索引已存在:{index_path}(如需重建,请加 --rebuild)")
        return

    # 1. 获取 corpus 目录
    corpus_dir = get_corpus_dir(brand, args.corpus)
    logger.info(f"corpus 目录:{corpus_dir}")

    # 2. 构建索引
    embedder = Embedder()
    chunks = build_index(brand, corpus_dir, logger, embedder)

    if not chunks:
        logger.warning("未生成任何 chunk,索引产物将为空。请检查 corpus 目录是否有 .md 文件。")
        return

    # 3. 保存索引
    save_index(index_path, chunks, logger)
    logger.info(f"=== [{BRAND_TO_PERSONA[brand]}({brand})] 索引构建完成 ===")


if __name__ == "__main__":
    main()
