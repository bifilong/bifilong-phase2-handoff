# 所有输出只能存到 G 盘（红线 · G 盘镜像）

> 本文件是 C 盘 `feedback_output_to_g_drive_only.md` 的 G 盘镜像。
> 真正权威源在 C 盘；本文件供 vault 内 Claude 直接读取。
>
> 按 [[feedback_disk_backup_policy]] 双盘策略。

## 硬规则（速查版）

- ✅ **只能**写到 `G:\Obsidian仓库\Claude-AI助手\` 下或其子目录
- ❌ **禁止** `C:\Users\57888\AppData\Local\Temp\...`
- ❌ **禁止** `C:\Users\57888\...` 用户目录（配置文件除外）
- ❌ **禁止** `/tmp/...`（Windows Git Bash 下 `/tmp/` 实际是 C 盘的 Temp）
- ❌ **禁止** `~/.lingzao/outputs/` 等用户 home 下的输出子目录

## 推荐 G 盘落点

| 用途 | 路径 |
|---|---|
| 灵造图片 | `G:\Obsidian仓库\Claude-AI助手\_tmp\lingzao-outputs\` |
| jimeng 图片 | `G:\Obsidian仓库\Claude-AI助手\_tmp\jimeng-outputs\` |
| 通用 image-gen 缓存 | `G:\Obsidian仓库\Claude-AI助手\_tmp\image-gen\` |
| 公众号文章 Markdown | `G:\Obsidian仓库\Claude-AI助手\_tmp\lingzao-outputs\articles\` |
| 海报最终归档 | `G:\Obsidian仓库\Claude-AI助手\wiki\活动海报提示词及文案\[品牌]\[品名]\` |
| 对标账号笔记 | `G:\Obsidian仓库\Claude-AI助手\wiki\_user_scripts\lingzao\对标账号\` |
| 备份 | `G:\Obsidian仓库\Claude-AI助手\_archive\` |

## 例外

- 配置文件（`~/.lingzao/config.json`、`~/.skillhub/config.json`）
- MEMORY 自动记忆（按 [[feedback_memory_management]] 强制 C 盘 + G 盘镜像）

## 出错回退

发现 C 盘路径 → 立即停 → 改 G 盘 → 重跑 → 标记已修正

## 触发

任何 `--output` / `curl -o` / `wget -O` / Python `open(..., 'w')` / 任何文件写入 → 路径必须是 G 盘
