---
name: feedback-wait-decisions
description: 用户"等 X 日期"决策是完整动作，cron 设上即结束；不要擅自加预备任务 / dry-run / 试爬
metadata:
  type: feedback
---

When user says "等 X 日期 reset 后启动" / "等 X 再做" as a complete decision, treat it as a complete plan with a single action (set trigger + wait). After cron / scheduled task is in place, the work is done — do NOT propose preparatory tasks, dry-runs, trial runs, or "可选 9/1 之前预热" actions before X.

**Why**: User views "等 X" as a final, complete decision, not a starting point for elaboration. v3.6 chain plan (2026-08-24) — user decided "等 9/1 reset 后一起启动 C3 + Phase 2-B · 一个 cron 触发 · 全链路完成" (4 short clauses, single intent). I expanded it into A/B/C/D/E "现在立刻做" + "9/1 之前预热" + "9/1 自动触发" three-tier checklist, then asked "要我立即去查吗？" — was corrected twice ("你有点乱了" / "你是不是没有接上我们以下这个任务的进度计划呢").

**How to apply**:
- "等 X" + cron/任务已设 → answer "什么都不用做，等 X 自动触发"
- 不要列 "现在立刻做" + "X 之前预热" + "X 自动触发" 三段动作
- 持久化备份（schtasks 等）是**可选兜底**，明确标注，不要混入主任务清单
- 如果有疑虑，问 "要不要 X？" 而不是直接列 A/B/C/D/E
- Agent 判断：用户偏好极简动作清单，对"预防性扩展任务"反感
- 关联: [[feedback_output_to_g_drive_only]] (极简偏好), [[feedback_xhs_sop]] (严格 SOP 不自由发挥)