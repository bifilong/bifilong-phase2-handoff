---
name: disk-backup-must-mirror-c-to-g
description: auto memory 必须双写到 G 盘 vault memory/，防 C 盘系统重装丢失
metadata:
  type: feedback
---

**规则**：每次新增/修改 auto memory 条目，必须同时写两份：
1. **C 盘（快速通道）**：`C:\Users\57888\.claude\projects\G--Obsidian---Claude-AI--\memory\`
   - 由 Claude Code 平台自动加载 MEMORY.md 到上下文
   - 风险：系统盘故障/重装/换电脑 → 全丢
2. **G 盘（主权备份）**：`G:\Obsidian仓库\Claude-AI助手\memory\`
   - 在用户 vault 工作区内，跟 git 走
   - 支持异地备份、版本控制

**Why:** C 盘是 Windows 系统盘，重装系统/换电脑/误删 `.claude` 文件夹都会丢失；用户已在 G 盘 vault 维护仓库 + git，单盘风险不可接受。2026-07-11 用户明确提出这个担忧。

**How to apply:**
- **Write 新条目**：必须同步写两份（C 盘 + G 盘各一份）
- **修改条目**：Edit 前先 Read 双盘 → 确认是否一致 → 同步双改
- **删除条目**：双盘都删
- **MEMORY.md 索引变动**：双盘同步 Edit
- **触发同步检查**的场景：
  - 用户说"重新检查双盘同步"
  - 我自己发现写入异常（如 C 盘写入失败但 G 盘成功）
  - 我读条目时怀疑某盘缺失

**G 盘路径模板**：
- 索引：`G:\Obsidian仓库\Claude-AI助手\memory\MEMORY.md`
- 详情：`G:\Obsidian仓库\Claude-AI助手\memory\<type>_<slug>.md`
- 归档：`G:\Obsidian仓库\Claude-AI助手\memory\_archive\MEMORY-{date}-snapshot.md`

**压缩规则变通**（已在 [[feedback_memory_management]] 定义）：C 盘和 G 盘都要压缩 + 各自 _archive/ 备份。

相关：[[feedback_memory_management]]
相关：[[reference_wechat_input_workflow]]