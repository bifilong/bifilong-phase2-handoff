---
name: memory-management-rules
description: MEMORY.md 自动压缩 + _archive 备份规则，防止记忆膨胀失忆
metadata:
  type: feedback
---

**MEMORY.md 硬约束**：系统自动加载到上下文，**第 201 行开始被截断不可见**。

**自动维护规则**（我自己执行）：

1. **MEMORY.md 超过 150 行** → 主动警告用户"接近 200 行上限，建议压缩"
2. **超过 180 行** → 立即自动触发压缩：
   - 把当前 MEMORY.md 整体复制到 `_archive/MEMORY-{YYYY-MM-DD}-snapshot.md`
   - 重新精简 MEMORY.md（合并相近条目 / 删除过期 / 拆分详情到独立文件）
   - 压缩后目标 ≤ 150 行
   - 详情永远保留在各自 `*.md` 文件里，**不丢任何信息**
3. **MEMORY.md 超过 100 行（健康区间外）** → 提示用户审视，是否有过期条目

**找回历史记忆**：
- 用户说"查 X 时间点的记忆" → 我 Read `_archive/MEMORY-{date}-snapshot.md`
- 任何历史 snapshot 都不会被删除，只增不删
- `_index/` 下的主题聚合（all_feedback.md / all_projects.md）按需 Read，**不自动加载**

**Why:** 200 行限制是平台硬约束，没法放宽；但用户的"备份 + 压缩"思路可以变通实现——既不超限，也不失忆。

**How to apply:**
- 每次新增/修改 MEMORY.md 时，检查行数
- 写新记忆时优先**精炼 description**（一句钩子），详细内容放独立 *.md
- 任何"我会想起 X 吗"的疑虑 → 先查 MEMORY.md，没有就 Read 独立文件

相关：[[user_role]]
相关：[[feedback_disk_backup_policy]]