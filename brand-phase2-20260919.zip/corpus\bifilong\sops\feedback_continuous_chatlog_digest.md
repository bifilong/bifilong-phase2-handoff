---
name: feedback-continuous-chatlog-digest
description: "用户会持续给聊天记录文件(企微/客户对话),Claude 必须定期读取并按系统整体整理清洗为知识(SOP/案例/AI 卡片)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3a561206-6fa0-40c8-a835-27f643f23160
---

用户持续输入工作流(2026-08-25 用户决策):

**规则**:用户会不断提供新的聊天记录文件(企微群聊、客户对话等),Claude 必须定期读取这些 raw 文件,并按照整体系统架构整理清洗为可用的知识内容(SOP/案例/AI 客服卡片/培训素材)。

**Why**:
- 客诉案例少是正常的,要慢慢积累各种类型
- raw 原始数据本身不可直接用,需要按系统角色映射清洗为可检索、可调用的知识资产
- 用户不会主动要求每一步,需要持续主动处理

**How to apply**:
- 用户每次给新聊天记录文件 → 立即识别文件位置 + 格式
- 按已有知识库角色分类(B 端门店 / C 端消费者 / 客诉 / 敏宝 / 营养 / 跨境 / 培训分享)
- 走 [[project_obsidian_cc_ai_system_gaps_20260824]] 七层架构:L0 raw → L1 案例库
- 输出位置默认:`知识库/05-实操指南/案例库-江西直营门店群/Obsidian CC-YYYY-MM-深挖N-标题-YYYYMMDD.md`
- 写入前确认档案名规范(`Obsidian CC-` 前缀)+ frontmatter author: Claude
- 客诉案例配 SOP-1.1-A/1.2-A/1.2-B;敏宝配 SOP-3-A;营养配 SOP-4.x-A;跨境配 SOP-5-A
- AI 卡片侧同步触发:每写 1 个深挖 → 检查 C-AI-*/B-AI-* 是否需要补 trigger_phrases / 关联卡片
- 完成本批次后停下等用户决策下一步(按 [[feedback_priority_sequencing]])

**关联**:[[feedback_priority_sequencing]] [[feedback_output_to_g_drive_only]] [[feedback_obsidian_cc_prefix]] [[project_obsidian_cc_ai_system_gaps_20260824]]