---
name: feedback-wecom-credential-leak-2026
description: 腾讯云 wecom-webhook 部署中 EncodingAESKey 因 grep 验证时整行回显被泄漏进对话,必须作废+轮换(2026-09-08 实战教训)
metadata:
  type: feedback
---

# 企微凭证泄漏教训(2026-09-08 实战)

## 事件

部署 wecom-webhook 阶段,用户用 nano 手动粘贴 43 位 EncodingAESKey 到 .env 后,**跑 `grep WECOM_AES_KEY .env` 验证是否写入,grep 默认输出整行 → 整串 43 位 key 回到对话上下文**。

真实泄漏的 key:`ecRFO8l2p8xK74u2MWzdCEOFiOcgp7n1L9iDBOk6QTh`(已作废)

## 根因(三重失误)

1. **命令选择错误**:`grep` 输出整行内容,不应该用作"验证是否写入"的检查命令
2. **没有提前警示**:Claude 应该主动告知用户"用 wc -c 比长度,不要 echo 完整内容"
3. **凭证轮换机制缺位**:让用户在 nano 粘贴前,应该先建立"作废预案"——默认该 key 已经在聊天留底

## 规则(钉死)

### Rule 1 · .env 验证一律走长度比对

```bash
# ✅ 安全:只比对长度
KEY=$(grep WECOM_AES_KEY .env | cut -d= -f2); echo "len=${#KEY}"

# ✅ 更安全:算 sha256 头 8 位
KEY=$(grep WECOM_AES_KEY .env | cut -d= -f2); echo -n "$KEY" | sha256sum | head -c 8

# ❌ 严禁:任何会回显完整 key 的命令
grep WECOM_AES_KEY .env
cat .env
env | grep AES
```

### Rule 2 · Claude 在让用户填 .env 前必须先警告

每次让用户在 nano 里粘贴任何凭证字段,**先**说明:

> ⚠️ nano 保存后,验证写入用 `echo "len=${#KEY}"` 比对长度,**不要再 cat / grep 完整内容**,否则会进对话留底。

### Rule 3 · 默认假设 nano 粘贴的 key 已泄漏

任何通过 nano 通道填进 .env 的凭证,**立即标记为"已泄漏,首次部署成功后必须轮换"**。即便用户没主动 echo,默认作废。

### Rule 4 · 验证脚本固化到 SOP

```bash
# wecom-webhook/.env 验证(只输出字段名 + 长度)
grep -E '^[A-Z_]+=' .env | awk -F= '{if(length($2)>0) print $1" len="length($2); else print $1" EMPTY"}'
```

输出形如:
```
WECOM_CORPID len=18
WECOM_AGENTID len=7
WECOM_SECRET len=32
WECOM_AES_KEY len=43  ← 只能看到长度,看不到内容
```

## Why

- 用户实际操作中存在"为了确认写入而 echo 内容"的本能反射
- 对话一旦留底,即使 Claude 后续不主动用,聊天存档 / 自动 memory / obsidian vault 都可能同步
- 真实 key 泄漏 = 攻击者可伪造企微回调消息 → 服务器侧需要在签名校验环节拦截

## How to apply

- 任何新 .env 字段写入,**默认走 nano 通道 + 长度比对**,不让用户 echo 完整内容
- Claude 自身:遇到 grep / cat / env 输出 .env 内容时,**主动提醒用户立即轮换该字段**
- 在 .env.example 注释里固化验证命令示例

## 相关

[[feedback_output_to_g_drive_only]] · [[feedback_china_api_mandatory]]
