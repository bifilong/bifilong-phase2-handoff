---
name: feedback-connect-authoritative-sources
description: 费曼/科普/医学/营养类问题必须连接权威源（EFSA/NIH ODS/PubMed 等），不凭印象答
metadata:
  type: feedback
---

**规则**：任何**科普 / 营养 / 医学 / 法规 / 合规** 类问题（费曼测试、笔记 4-1 的 5:1 比例、钙片红线、成分功效等），必须**先 WebSearch 或 WebFetch 权威源**（EFSA、NIH ODS、PubMed、Cochrane、FDA GRAS、欧盟健康声称注册库），再给答案。

**禁止**：
- 仅凭模型训练记忆回答（容易编造或失实）
- 用"通常认为""一般来说""研究表明"等模糊措辞代替引用
- 用模型自带知识冒充用户笔记里写过的内容（vault 内容必须 Read 原文，外部知识必须 WebSearch/Wiki）

**优先权威源清单**：
- **EFSA**（欧洲食品安全局，efsa.europa.eu）—— 健康声称权威
- **NIH ODS**（ods.od.nih.gov）—— 营养素事实表
- **PubMed**（ncbi.nlm.nih.gov/pubmed）—— 临床研究
- **FDA GRAS** —— 食品添加剂公认安全
- **Cochrane Library** —— 系统评价
- **EU Register of Nutrition Claims** —— 已授权 / 拒绝的健康声称

**Why:** 用户 2026-07-11 反馈："为什么是 5 而不是 4 或 6，这个你要去连接到有权威网站做求证"——明确指出科普类问题必须查权威源，不接受凭印象答。

**How to apply:**
- 收到"为什么是 X""X 的原理是什么""X 有用吗"等问题 → 第一步 WebSearch → 不直接答
- 引用权威源时必须给可点击链接
- 区分"权威源结论"和"Agent 推断"，前者直接引用，后者标 `(Agent 判断)`
- 营养/医学类问题不止要"看上去对"，要"权威源能查"

相关：[[feedback_compliance]]
相关：[[user_role]]