"""
search.py — 3 品牌独立 RAG 检索接口(Hybrid: Dense + BM25 + RRF)

主导方:本机 Claude(Phase 1)
不动方:Hermes
拍板:P1-D1(bge-small-zh-v1.5)+ P1-D2(Hybrid + RRF)+ P1-D3(400/80)+ P1-D4(pickle)+ P1-D5(立即启动)
      D6(α 方案)+ D13(3 品牌人格名 慧慧/诺诺/鑫鑫)

用法:
    # 命令行模式
    python -m rag.search --brand=bifilong --query "葡聚糖饮怎么喝" --top_k=5

    # Python 调用
    from rag.search import search
    results = search("葡聚糖饮怎么喝", top_k=5, brand="bifilong")
    for chunk in results:
        print(chunk["text"])

检索策略:P1-D2 = γ Hybrid(Dense + BM25 + RRF 重排,k=60)
"""

import argparse
import json
import logging
import pickle
import re
import sys
from pathlib import Path
from typing import List, Optional, Tuple

# 复用 index_vault 的配置与数据结构
from rag.index_vault import (
    Chunk,
    Embedder,
    BRAND_TO_BOT_DIR,
    BRAND_TO_PERSONA,
    INDEX_ROOT,
    setup_logger,
)


# ============== 检索策略 ==============

def cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    """cosine 相似度(假设向量已 L2 归一化)"""
    if len(vec_a) != len(vec_b):
        return 0.0
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    return dot  # 归一化后 dot == cosine


def search_dense(query: str, brand: str, top_k: int = 15, logger: Optional[logging.Logger] = None) -> List[dict]:
    """Dense retrieval:cosine 相似度(返回 top_k 段)"""
    index_path = _get_index_path(brand)
    chunks = _load_chunks(index_path, logger)
    embedder = Embedder()
    query_vec = embedder.embed([query])[0]

    scored: List[Tuple[float, Chunk]] = []
    for chunk in chunks:
        score = cosine_similarity(query_vec, chunk.embedding)
        scored.append((score, chunk))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [_format_result(rank, score, chunk) for rank, (score, chunk) in enumerate(scored[:top_k], 1)]


def _tokenize_chinese(text: str) -> List[str]:
    """中文分词(jieba 优先,fallback 字符级)"""
    try:
        import jieba
        jieba.setLogLevel(logging.WARNING)
        return [t for t in jieba.cut(text) if t.strip()]
    except ImportError:
        # fallback:字符级 + 2-gram(简单但够用)
        text = re.sub(r"\s+", "", text)
        tokens = list(text)
        # 加 2-gram
        tokens += [text[i:i+2] for i in range(len(text) - 1)]
        return tokens


def _build_bm25_index(chunks: List[Chunk], logger: Optional[logging.Logger] = None):
    """构建 BM25 索引"""
    from rank_bm25 import BM25Okapi

    if logger:
        logger.info(f"开始构建 BM25 索引({len(chunks)} chunks)...")

    tokenized_corpus = [_tokenize_chinese(chunk.text) for chunk in chunks]
    bm25 = BM25Okapi(tokenized_corpus)

    if logger:
        logger.info("BM25 索引构建完成")
    return bm25


def _save_bm25_index(bm25_path: Path, bm25, logger: Optional[logging.Logger] = None):
    """保存 BM25 索引"""
    with open(bm25_path, "wb") as f:
        pickle.dump(bm25, f, protocol=pickle.HIGHEST_PROTOCOL)
    if logger:
        size_mb = bm25_path.stat().st_size / (1024 * 1024)
        logger.info(f"BM25 索引已保存:{bm25_path}({size_mb:.2f} MB)")


def _load_bm25_index(bm25_path: Path, chunks: List[Chunk], logger: Optional[logging.Logger] = None):
    """加载 BM25 索引(不存在则构建并保存)"""
    if bm25_path.exists():
        if logger:
            logger.info(f"加载 BM25 索引:{bm25_path}")
        with open(bm25_path, "rb") as f:
            return pickle.load(f)

    bm25 = _build_bm25_index(chunks, logger)
    _save_bm25_index(bm25_path, bm25, logger)
    return bm25


def search_bm25(query: str, brand: str, top_k: int = 15, logger: Optional[logging.Logger] = None) -> List[dict]:
    """BM25 retrieval:关键词匹配(返回 top_k 段)"""
    index_path = _get_index_path(brand)
    chunks = _load_chunks(index_path, logger)

    bm25_path = _get_bm25_path(brand)
    bm25 = _load_bm25_index(bm25_path, chunks, logger)

    query_tokens = _tokenize_chinese(query)
    scores = bm25.get_scores(query_tokens)

    # 排序(top_k)
    ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:top_k]

    return [_format_result(rank, float(score), chunks[idx]) for rank, (idx, score) in enumerate(ranked, 1)]


def rrf_fusion(dense_results: List[dict], bm25_results: List[dict], top_k: int = 5, k: int = 60) -> List[dict]:
    """Reciprocal Rank Fusion(Dense + BM25 融合重排)

    Args:
        dense_results: Dense 检索结果
        bm25_results: BM25 检索结果
        top_k: 返回 top_k 段
        k: RRF 参数(常用 60)

    Returns:
        融合后的 top_k 段
    """
    scores = {}
    for rank, item in enumerate(dense_results, 1):
        chunk_id = item["chunk_id"]
        scores[chunk_id] = scores.get(chunk_id, 0.0) + 1.0 / (k + rank)
    for rank, item in enumerate(bm25_results, 1):
        chunk_id = item["chunk_id"]
        scores[chunk_id] = scores.get(chunk_id, 0.0) + 1.0 / (k + rank)

    # 按 RRF 分数排序
    sorted_ids = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    # 索引映射
    all_items = {item["chunk_id"]: item.copy() for item in dense_results + bm25_results}

    results = []
    for rank, (chunk_id, rrf_score) in enumerate(sorted_ids[:top_k], 1):
        item = all_items[chunk_id]
        item["rank"] = rank
        item["rrf_score"] = round(rrf_score, 6)
        item["hybrid_method"] = "Dense+BM25+RRF"
        results.append(item)

    return results


def search_hybrid(query: str, brand: str, top_k: int = 5, logger: Optional[logging.Logger] = None) -> List[dict]:
    """Hybrid retrieval(Dense + BM25 + RRF 重排,P1-D2 拍板)

    实现:
        1. Dense 召回 top_k*3(默认 15)
        2. BM25 召回 top_k*3
        3. RRF 重排(k=60)
        4. 取 top_k
    """
    if logger:
        logger.info(f"Hybrid 检索:query={query!r}")

    # Step 1: Dense 召回
    dense_top_k = top_k * 3
    dense_results = search_dense(query, brand, top_k=dense_top_k, logger=logger)

    # Step 2: BM25 召回
    bm25_results = search_bm25(query, brand, top_k=dense_top_k, logger=logger)

    # Step 3: RRF 融合
    fused = rrf_fusion(dense_results, bm25_results, top_k=top_k, k=60)

    if logger:
        logger.info(f"Hybrid 检索完成:{len(fused)} 段(从 {len(dense_results)} dense + {len(bm25_results)} bm25 融合)")
    return fused


# ============== 工具函数 ==============

def _get_index_path(brand: str) -> Path:
    bot_dir = BRAND_TO_BOT_DIR[brand]
    return INDEX_ROOT / bot_dir / "rag" / f"index_{brand}.pkl"


def _get_bm25_path(brand: str) -> Path:
    bot_dir = BRAND_TO_BOT_DIR[brand]
    return INDEX_ROOT / bot_dir / "rag" / f"index_{brand}.bm25.pkl"


def _load_chunks(index_path: Path, logger: Optional[logging.Logger] = None) -> List[Chunk]:
    if not index_path.exists():
        raise FileNotFoundError(f"索引不存在:{index_path}(请先运行 index_vault.py)")
    if logger:
        logger.info(f"加载 chunks 索引:{index_path}")
    with open(index_path, "rb") as f:
        chunks: List[Chunk] = pickle.load(f)
    if logger:
        logger.info(f"chunks 索引加载完成:{len(chunks)} chunks")
    return chunks


def _format_result(rank: int, score: float, chunk: Chunk) -> dict:
    return {
        "rank": rank,
        "score": round(float(score), 4),
        "chunk_id": chunk.chunk_id,
        "brand": chunk.brand,
        "source_filename": chunk.source_filename,
        "source_path": chunk.source_path,
        "text": chunk.text,
        "metadata": chunk.metadata,
    }


# ============== 统一入口 ==============

def search(query: str, top_k: int = 5, brand: str = "bifilong") -> List[dict]:
    """统一检索入口(默认 Hybrid:Dense + BM25 + RRF)

    Args:
        query: 用户查询文本
        top_k: 返回 top_k 段
        brand: 品牌(bifilong / shengnuoxiong / xinyao)

    Returns:
        检索结果列表,每项含 rank / score / chunk_id / text / rrf_score 等
    """
    if brand not in BRAND_TO_BOT_DIR:
        raise ValueError(f"未知 brand:{brand},可选:{list(BRAND_TO_BOT_DIR.keys())}")
    return search_hybrid(query, brand, top_k)


# ============== CLI ==============

def main():
    parser = argparse.ArgumentParser(
        description="3 品牌独立 RAG 检索接口(Hybrid:Dense + BM25 + RRF)",
    )
    parser.add_argument("--brand", type=str, required=True,
                        choices=["bifilong", "shengnuoxiong", "xinyao"])
    parser.add_argument("--query", type=str, required=True, help="查询文本")
    parser.add_argument("--top_k", type=int, default=5, help="返回 top_k 段(默认 5)")
    parser.add_argument("--strategy", type=str, default="hybrid",
                        choices=["hybrid", "dense", "bm25"],
                        help="检索策略:hybrid(Dense+BM25+RRF,默认)/ dense / bm25")
    parser.add_argument("--output", type=str, default=None,
                        help="输出到 JSON 文件(默认打印到 stdout)")

    args = parser.parse_args()
    brand = args.brand
    logger = setup_logger(brand)

    logger.info(f"=== [{BRAND_TO_PERSONA[brand]}({brand})] 检索:strategy={args.strategy}, query={args.query!r} ===")

    if args.strategy == "hybrid":
        results = search_hybrid(args.query, brand, args.top_k, logger)
    elif args.strategy == "dense":
        results = search_dense(args.query, brand, args.top_k, logger)
    else:
        results = search_bm25(args.query, brand, args.top_k, logger)

    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump({
                "brand": brand,
                "persona": BRAND_TO_PERSONA[brand],
                "query": args.query,
                "strategy": args.strategy,
                "top_k": args.top_k,
                "results": results,
            }, f, ensure_ascii=False, indent=2)
        logger.info(f"结果已保存:{output_path}")
    else:
        print(f"\n=== Top {len(results)} 召回({args.strategy})===")
        for r in results:
            extra_score = r.get("rrf_score", r.get("score"))
            print(f"\n[Rank {r['rank']}] score={r['score']} rrf={extra_score:.4f} | {r['source_filename']}")
            print(f"  {r['text'][:200]}{'...' if len(r['text']) > 200 else ''}")


if __name__ == "__main__":
    main()
